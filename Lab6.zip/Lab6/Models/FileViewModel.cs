﻿namespace Lab6.Models
{
    public class FileViewModel
    {
        public String Name { get; set; }
        public IFormFile FilePath { get; set; }
    }
}
