﻿namespace Lab6.Models.ViewModels
{
    public class ForumMessageCreateModel
    {
        public String Text { get; set; }
    }
}
