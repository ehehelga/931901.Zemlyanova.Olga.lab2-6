﻿using System.ComponentModel.DataAnnotations;

namespace Lab6.Models.ViewModels
{
    public class ForumTopicCreateModel
    {
        public DateTime Created { get; set; }
        [Required]
        public String Name { get; set; }
    }
}
